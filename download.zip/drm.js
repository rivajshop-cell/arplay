
/*
 * AR STREAM TESTER
 * File: drm.js
 * Developed by AR STUDIO
 *
 * DRM Support Information & Configuration
 */

const AR_DRM = {

    currentSystem: "none",

    systems: {
        none: {
            name: "No DRM",
            supported: true
        },

        widevine: {
            name: "Google Widevine",
            keySystem: "com.widevine.alpha"
        },

        playready: {
            name: "Microsoft PlayReady",
            keySystem: "com.microsoft.playready"
        },

        fairplay: {
            name: "Apple FairPlay",
            keySystem: "com.apple.fps.1_0"
        },

        clearkey: {
            name: "ClearKey",
            keySystem: "org.w3.clearkey"
        }
    }

};

/* Check browser DRM support */
async function checkDRMSupport(system) {

    const drm = AR_DRM.systems[system];

    if (!drm) {
        return {
            supported: false,
            message: "Unknown DRM system."
        };
    }

    if (system === "none") {
        return {
            supported: true,
            message: "No DRM selected."
        };
    }

    if (!navigator.requestMediaKeySystemAccess) {

        return {
            supported: false,
            message: "Browser EME API is unavailable."
        };

    }

    try {

        const configuration = [{
            initDataTypes: ["cenc"],
            videoCapabilities: [{
                contentType: 'video/mp4; codecs="avc1.42E01E"'
            }]
        }];

        await navigator.requestMediaKeySystemAccess(
            drm.keySystem,
            configuration
        );

        return {
            supported: true,
            message: drm.name + " is supported by this browser."
        };

    } catch (error) {

        return {
            supported: false,
            message: drm.name + " is not available for this browser configuration."
        };

    }

}

/* Test selected DRM */
async function testDRM(system) {

    AR_DRM.currentSystem = system;

    addLog("Checking DRM: " + system.toUpperCase());

    const result = await checkDRMSupport(system);

    if (result.supported) {

        addLog("DRM RESULT: " + result.message);

    } else {

        addLog("DRM WARNING: " + result.message);

    }

    return result;

}

/* Show DRM capabilities */
async function getDRMCapabilities() {

    const results = {};

    for (const system of Object.keys(AR_DRM.systems)) {

        results[system] = await checkDRMSupport(system);

    }

    return results;

}

/* Display DRM information */
async function displayDRMInfo() {

    addLog("Starting DRM compatibility check...");

    const results = await getDRMCapabilities();

    Object.keys(results).forEach(system => {

        const result = results[system];

        addLog(
            system.toUpperCase() +
            ": " +
            (result.supported ? "SUPPORTED" : "NOT AVAILABLE")
        );

    });

    addLog("DRM compatibility check completed.");

    return results;

}

/* Get selected DRM */
function getSelectedDRM() {

    return AR_DRM.currentSystem;

}

/* Initialization */
document.addEventListener("DOMContentLoaded", function() {

    addLog("AR DRM module loaded.");

    addLog("Supported DRM systems: Widevine, PlayReady, FairPlay, ClearKey.");

});
