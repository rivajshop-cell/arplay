/* AR Stream Tester - custom HTML5 player controls */
document.addEventListener('DOMContentLoaded',()=>{
 const video=document.getElementById('videoPlayer');if(!video)return;
 const $=id=>document.getElementById(id);
 const play=$('playPause'),seek=$('seekBar'),current=$('currentTime'),total=$('totalTime'),mute=$('muteBtn'),volume=$('volumeBar'),speed=$('speedSelect'),fullscreen=$('fullscreenBtn'),placeholder=$('videoPlaceholder'),loading=$('videoLoading'),error=$('videoError'),frame=$('videoFrame'),format=$('playerFormat');
 const fmt=t=>{if(!Number.isFinite(t))return '00:00';const h=Math.floor(t/3600),m=Math.floor(t%3600/60),s=Math.floor(t%60);return h?`${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`:`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`};
 const setPlaying=()=>{play.textContent=video.paused?'▶':'Ⅱ';};
 play.addEventListener('click',()=>{if(video.paused)video.play().catch(()=>{});else video.pause();});
 video.addEventListener('play',()=>{setPlaying();placeholder.style.display='none';error.classList.remove('show');});video.addEventListener('pause',setPlaying);video.addEventListener('ended',setPlaying);
 video.addEventListener('loadedmetadata',()=>{total.textContent=Number.isFinite(video.duration)?fmt(video.duration):'LIVE';$('infoType').textContent=(window.currentStreamType||'Stream').toUpperCase();$('infoResolution').textContent=video.videoWidth&&video.videoHeight?`${video.videoWidth} × ${video.videoHeight}`:'Not available';$('infoDuration').textContent=Number.isFinite(video.duration)?fmt(video.duration):'Live / Unknown';});
 video.addEventListener('timeupdate',()=>{current.textContent=fmt(video.currentTime);if(Number.isFinite(video.duration)&&video.duration>0)seek.value=String(video.currentTime/video.duration*1000);});
 seek.addEventListener('input',()=>{if(Number.isFinite(video.duration)&&video.duration>0)video.currentTime=Number(seek.value)/1000*video.duration;});
 mute.addEventListener('click',()=>{video.muted=!video.muted;mute.textContent=video.muted?'◖×':'◖))';});volume.addEventListener('input',()=>{video.volume=Number(volume.value);video.muted=video.volume===0;mute.textContent=video.muted?'◖×':'◖))';});
 speed.addEventListener('change',()=>{video.playbackRate=Number(speed.value);});
 fullscreen.addEventListener('click',()=>{if(document.fullscreenElement)document.exitFullscreen?.();else (frame.requestFullscreen?.()||video.webkitEnterFullscreen?.());});
 video.addEventListener('waiting',()=>loading.classList.add('show'));video.addEventListener('playing',()=>{loading.classList.remove('show');placeholder.style.display='none';$('infoPlayback').textContent='Playing';});video.addEventListener('canplay',()=>loading.classList.remove('show'));video.addEventListener('error',()=>{loading.classList.remove('show');$('infoPlayback').textContent='Playback Error';});
 document.getElementById('testBtn')?.addEventListener('click',()=>{placeholder.style.display='none';error.classList.remove('show');loading.classList.add('show');format.textContent='LOADING STREAM';});
 const oldStatus=window.updatePlayerStatus;window.updatePlayerStatus=function(s){if(oldStatus)oldStatus(s);if(format)format.textContent=String(s).toUpperCase();if(loading&&/READY/.test(s))loading.classList.remove('show');if(loading&&/ERROR|STOPPED/.test(s))loading.classList.remove('show');};
 window.addEventListener('beforeunload',()=>{video.pause();});
});
