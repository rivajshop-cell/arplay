
/*
 * AR STREAM TESTER
 * File: player.js
 * Developed by AR STUDIO
 */

let hlsPlayer = null;
let dashPlayer = null;

const video = document.getElementById("videoPlayer");

/* Detect stream format */
function detectStreamType(url, selectedType) {

    if (selectedType !== "auto") {
        return selectedType;
    }

    const cleanUrl = url.toLowerCase().split("?")[0];

    if (cleanUrl.endsWith(".m3u8")) return "hls";
    if (cleanUrl.endsWith(".mpd")) return "dash";
    if (cleanUrl.endsWith(".mp4")) return "mp4";

    return "unknown";
}

/* Destroy previous players */
function destroyPlayers() {

    if (hlsPlayer) {
        hlsPlayer.destroy();
        hlsPlayer = null;
    }

    if (dashPlayer) {
        dashPlayer.reset();
        dashPlayer = null;
    }

    video.pause();
    video.removeAttribute("src");
    video.load();
}

/* HLS Player */
function loadHLS(url) {

    if (Hls.isSupported()) {

        hlsPlayer = new Hls({
            enableWorker: true,
            lowLatencyMode: true
        });

        hlsPlayer.loadSource(url);
        hlsPlayer.attachMedia(video);

        hlsPlayer.on(Hls.Events.MANIFEST_PARSED, function () {

            addLog("HLS manifest loaded successfully.");
            updatePlayerStatus("HLS READY");

            video.play().catch(() => {
                addLog("Press play to start playback.");
            });

        });

        hlsPlayer.on(Hls.Events.ERROR, function (event, data) {

            addLog(
                "HLS Error: " +
                data.type +
                " | " +
                data.details
            );

            if (data.fatal) {
                updatePlayerStatus("HLS ERROR");
                addLog("Fatal HLS error detected.");
            }
        });

    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {

        video.src = url;

        video.addEventListener("loadedmetadata", function () {
            addLog("Native HLS playback supported.");
            updatePlayerStatus("HLS READY");
        }, { once: true });

        video.play().catch(() => {
            addLog("Press play to start playback.");
        });

    } else {

        throw new Error("HLS is not supported by this browser.");
    }
}

/* DASH Player */
function loadDASH(url) {

    if (!window.dashjs) {
        throw new Error("DASH.js library is unavailable.");
    }

    dashPlayer = dashjs.MediaPlayer().create();

    dashPlayer.initialize(video, url, false);

    dashPlayer.on(
        dashjs.MediaPlayer.events.STREAM_INITIALIZED,
        function () {

            addLog("DASH stream initialized.");
            updatePlayerStatus("DASH READY");

            video.play().catch(() => {
                addLog("Press play to start playback.");
            });

        }
    );

    dashPlayer.on(
        dashjs.MediaPlayer.events.ERROR,
        function (event) {

            addLog(
                "DASH Error: " +
                JSON.stringify(event.error || event)
            );

            updatePlayerStatus("DASH ERROR");
        }
    );
}

/* MP4 Player */
function loadMP4(url) {

    video.src = url;

    video.addEventListener("loadedmetadata", function () {

        addLog("MP4 metadata loaded.");
        updatePlayerStatus("MP4 READY");

    }, { once: true });

    video.play().catch(() => {
        addLog("Press play to start playback.");
    });
}

/* Main player function */
function playStream(url, type) {

    window.currentStreamType = type;
    const infoType = document.getElementById("infoType");
    if (infoType) infoType.textContent = String(type).toUpperCase();
    destroyPlayers();

    try {

        if (!url) {
            throw new Error("Please enter a stream URL.");
        }

        addLog("Initializing stream player...");
        addLog("Stream type: " + type);

        if (type === "hls") {

            loadHLS(url);

        } else if (type === "dash") {

            loadDASH(url);

        } else if (type === "mp4") {

            loadMP4(url);

        } else {

            throw new Error(
                "Unknown stream type. Select HLS, DASH or MP4 manually."
            );
        }

    } catch (error) {

        addLog("Player Error: " + error.message);
        updatePlayerStatus("ERROR");

    }
}

/* Stop playback */
function stopPlayer() {

    window.currentStreamType = "";
    destroyPlayers();

    updatePlayerStatus("STOPPED");

    addLog("Playback stopped.");
}

/* Player status */
function updatePlayerStatus(status) {

    const element = document.getElementById("playerStatus");

    if (element) {
        element.textContent = status;
    }
}

/* Video information */
video.addEventListener("loadedmetadata", function () {

    const width = video.videoWidth;
    const height = video.videoHeight;

    document.getElementById("infoResolution").textContent =
        width && height ? width + " × " + height : "Unknown";

    document.getElementById("infoDuration").textContent =
        Number.isFinite(video.duration)
            ? Math.round(video.duration) + " seconds"
            : "Live / Unknown";

});

video.addEventListener("playing", function () {

    document.getElementById("infoPlayback").textContent = "Playing";

    addLog("Video playback started.");

});

video.addEventListener("waiting", function () {

    document.getElementById("infoPlayback").textContent = "Buffering";

});

video.addEventListener("pause", function () {

    if (!video.ended) {
        document.getElementById("infoPlayback").textContent = "Paused";
    }

});

video.addEventListener("error", function () {

    document.getElementById("infoPlayback").textContent = "Playback Error";

    addLog("Browser video playback error.");

});
