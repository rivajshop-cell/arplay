
/* =====================================
   AR STREAM TESTER - MAIN.JS
   Developed by AR STUDIO
===================================== */

document.addEventListener("DOMContentLoaded", () => {
    addLog("AR STREAM TESTER تیار ہے۔", "success");
    updatePlayerInfo();
});

function testStream() {
    const urlInput = document.getElementById("streamUrl");
    const typeInput = document.getElementById("streamType");

    if (!urlInput || !typeInput) {
        addLog("ضروری HTML عناصر نہیں ملے۔", "error");
        return;
    }

    const url = urlInput.value.trim();
    let type = typeInput.value;

    if (!url) {
        setStatus("براہِ کرم Stream URL درج کریں۔", "error");
        addLog("Stream URL خالی ہے۔", "error");
        return;
    }

    try {
        const parsedUrl = new URL(url);

        if (!["http:", "https:"].includes(parsedUrl.protocol)) {
            throw new Error("صرف HTTP اور HTTPS لنکس قابلِ قبول ہیں۔");
        }
    } catch (error) {
        setStatus("درست URL درج کریں۔", "error");
        addLog("URL درست نہیں ہے۔", "error");
        return;
    }

    if (type === "auto") {
        const lowerUrl = url.toLowerCase();

        if (lowerUrl.includes(".m3u8")) {
            type = "hls";
        } else if (lowerUrl.includes(".mpd")) {
            type = "dash";
        } else if (/\.(mp4|webm|ogg)(\?|$)/i.test(lowerUrl)) {
            type = "mp4";
        }
    }

    addLog("نیا Stream ٹیسٹ شروع ہو رہا ہے۔", "info");
    addLog("Stream Type: " + type.toUpperCase(), "info");

    setStatus("Stream لوڈ ہو رہی ہے...", "loading");

    if (typeof stopPlayer === "function") {
        stopPlayer();
    }

    if (typeof playStream === "function") {
        playStream(url, type);
    } else {
        setStatus("Player فائل نہیں ملی۔", "error");
        addLog("player.js میں playStream() موجود نہیں۔", "error");
    }
}

function stopStream() {
    if (typeof stopPlayer === "function") {
        stopPlayer();
    }

    const video = document.getElementById("videoPlayer");

    if (video) {
        video.pause();
        video.removeAttribute("src");
        video.load();
    }

    setStatus("Stream بند کر دی گئی۔", "info");
    addLog("Player بند کر دیا گیا۔", "info");
    updatePlayerInfo();
}

function setStatus(message, type = "info") {
    const status = document.getElementById("status");

    if (status) {
        status.textContent = message;
        status.className = "status " + type;
    }
}

function addLog(message, type = "info") {
    const logs = document.getElementById("logs");

    if (!logs) {
        console.log(message);
        return;
    }

    const item = document.createElement("div");
    item.className = "log-item " + type;

    const time = new Date().toLocaleTimeString();

    item.textContent = "[" + time + "] " + message;

    logs.prepend(item);
}

function clearLogs() {
    const logs = document.getElementById("logs");

    if (logs) {
        logs.innerHTML = "";
        addLog("Logs صاف کر دی گئی ہیں۔", "success");
    }
}

function updatePlayerInfo() {
    const video = document.getElementById("videoPlayer");

    if (!video) return;

    const playback = document.getElementById("infoPlayback");
    const resolution = document.getElementById("infoResolution");
    const duration = document.getElementById("infoDuration");

    if (playback) {
        playback.textContent = video.paused ? "Stopped" : "Playing";
    }

    if (resolution) {
        resolution.textContent =
            video.videoWidth && video.videoHeight
                ? video.videoWidth + " × " + video.videoHeight
                : "Not available";
    }

    if (duration) {
        duration.textContent =
            Number.isFinite(video.duration)
                ? Math.floor(video.duration) + " seconds"
                : "Live / Unknown";
    }
}

const videoElement = document.getElementById("videoPlayer");

if (videoElement) {
    ["playing", "pause", "loadedmetadata", "error", "waiting"].forEach(event => {
        videoElement.addEventListener(event, updatePlayerInfo);
    });
}
