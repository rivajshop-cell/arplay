AR STREAM TESTER - BLUE / WHITE GLASS UI
Developed by AR STUDIO

UPLOAD
1. Extract this ZIP.
2. Upload all files into the same public_html / htdocs folder.
3. Keep the file names and folder structure unchanged.
4. Open index.html (or your domain root if configured to serve it).

FILES
index.html    Main responsive dashboard
style.css     Blue/white glassmorphism interface
player-ui.js  Custom HTML5-style player controls
main.js       Stream testing workflow and diagnostics
player.js     HLS / DASH / MP4 playback engine
embed.php     Standalone responsive embed player
drm.js       Browser DRM capability checker
.htaccess     Original server rules retained

NOTES
- Existing stream testing functions and IDs have been retained.
- The player skin uses custom HTML5 controls: play/pause, seek, volume, speed and fullscreen.
- HLS.js and DASH.js are loaded from their public CDNs, as in the original project.
- Use only stream URLs you own or are authorized to test. This interface does not bypass DRM or provider access controls.
- PHP hosting is required for embed.php.
